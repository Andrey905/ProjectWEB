def hw1(update, context):
    try:
        a = context.args
        dt = a[0]
        les = a[1]
        dz = (' ').join(a[2:])
        import sqlalchemy
        from flask import Flask
        import sqlalchemy.ext.declarative as dec
        from data import db_session
        from data.db_session import SqlAlchemyBase
        db_session.global_init('db/blogs.db')
        db_sess = db_session.create_session()
        from data.WeekDay_DateDay import WeekDay_DateDay
        from data.HomeWork import HomeWork
        from data.D_Schedule import D_Schedule
        from data.ScheduleFact import ScheduleFact
        from data.D_Lesson import D_Lesson
        from data.BE_Lesson_Time import BE_Lesson_Time
        for WeekDay_DateDay in db_sess.query(WeekDay_DateDay).filter(WeekDay_DateDay.date == dt):
            id_day = WeekDay_DateDay.id
        HomeWork1 = HomeWork()
        HomeWork1.date_id = id_day
        HomeWork1.text_homework = dz

        import sqlite3
        con = sqlite3.connect('db/blogs.db')
        cur = con.cursor()
        result = cur.execute("""SELECT ScheduleFact.id FROM ScheduleFact
            JOIN D_Schedule on ScheduleFact.schedule_id = D_Schedule.id
            JOIN WeekDay_DateDay on ScheduleFact.date_id = WeekDay_DateDay.id
            JOIN D_Lesson on D_Schedule.lesson_id = D_Lesson.id
            where WeekDay_DateDay.date = '%s'
            and D_Lesson.lesson_name = '%s'""" % (dt, les)).fetchall()
        for elem in result:
            b = elem[0]
        con.close()

        HomeWork1.schedulefact_id = b
        db_sess = db_session.create_session()
        db_sess.add(HomeWork1)
        db_sess.commit()
        update.message.reply_text("записано")
    except:
        update.message.reply_text("упс")
