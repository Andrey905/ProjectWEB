import sqlalchemy
from data import db_session
from .db_session import SqlAlchemyBase



class BE_WeekDay(SqlAlchemyBase):
    __tablename__ = 'BE_WeekDay'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=True)
    weekday_name = sqlalchemy.Column(sqlalchemy.String, nullable=True)

def BE_WeekDay_init():
    d = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'] 
    for i in range(len(d)):
        BE_WeekDay1 = BE_WeekDay()
        BE_WeekDay1.weekday_name = d[i]
        db_sess = db_session.create_session()
        db_sess.add(BE_WeekDay1)
        db_sess.commit()

