import sqlalchemy
import datetime
from data import db_session
from .db_session import SqlAlchemyBase


class D_Schedule(SqlAlchemyBase):
    __tablename__ = 'D_Schedule'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    weekday_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("BE_WeekDay.id"), nullable=False)
    lesson_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("D_Lesson.id"), nullable=False)
    lesson_num = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("BE_Lesson_Time.lesson_num"), nullable=False)


def D_Schedule_init():
    l = [1, 1, 10, 2, 2, 1, 2]
    for i in range(len(l)):
        Mon = D_Schedule()
        Mon.weekday_id = 1
        Mon.lesson_id = l[i]
        Mon.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Mon)
        db_sess.commit()

    l = [5, 2, 4, 3, 13]
    for i in range(len(l)):
        Tue = D_Schedule()
        Tue.weekday_id = 2
        Tue.lesson_id = l[i]
        Tue.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Tue)
        db_sess.commit()

    l = [14, 14, 6, 6, 9, 11]
    for i in range(len(l)):
        Wed = D_Schedule()
        Wed.weekday_id = 3
        Wed.lesson_id = l[i]
        Wed.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Wed)
        db_sess.commit()

    l = [5, 7, 8, 8, 3]
    for i in range(len(l)):
        Thu = D_Schedule()
        Thu.weekday_id = 4
        Thu.lesson_id = l[i]
        Thu.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Thu)
        db_sess.commit()

    l = [2, 2, 1, 1, 12, 12]
    for i in range(len(l)):
        Fri = D_Schedule()
        Fri.weekday_id = 5
        Fri.lesson_id = l[i]
        Fri.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Fri)
        db_sess.commit()

    l = [7, 6, 14, 14, 8, 1]
    for i in range(len(l)):
        Sat = D_Schedule()
        Sat.weekday_id = 6
        Sat.lesson_id = l[i]
        Sat.lesson_num = i + 1
        db_sess = db_session.create_session()
        db_sess.add(Sat)
        db_sess.commit()
