import sqlalchemy
from data import db_session
from .db_session import SqlAlchemyBase


class BE_Lesson_Time(SqlAlchemyBase):
    __tablename__ = 'BE_Lesson_Time'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    lesson_num = sqlalchemy.Column(sqlalchemy.Integer, nullable=False)
    lessontime = sqlalchemy.Column(sqlalchemy.String, nullable=False)


def BE_Lesson_Time_init():
    t = ['8:30-9:10', '9:20-10:00', '10:20-11:00', '11:20-12:00', '12:20-13:00', '13:15-13:55', '14:10-14:50']
    for i in range(len(t)):
        BE_Lesson_Time1 = BE_Lesson_Time()
        BE_Lesson_Time1.lesson_num = i + 1
        BE_Lesson_Time1.lessontime = t[i]
        db_sess = db_session.create_session()
        db_sess.add(BE_Lesson_Time1)
        db_sess.commit()
