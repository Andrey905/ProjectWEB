import sqlalchemy
from .db_session import SqlAlchemyBase


class HomeWork(SqlAlchemyBase):
    __tablename__ = 'HomeWork'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    date_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("WeekDay_DateDay.id"))
    schedulefact_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("ScheduleFact.id"))
    text_homework = sqlalchemy.Column(sqlalchemy.String, default='', nullable=False)
    result_type = sqlalchemy.Column(sqlalchemy.Boolean, default=False, nullable=False)

