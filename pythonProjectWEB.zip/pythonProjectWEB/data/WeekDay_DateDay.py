import sqlalchemy
from data import db_session
import datetime
from datetime import timedelta
from .db_session import SqlAlchemyBase


class WeekDay_DateDay(SqlAlchemyBase):
    __tablename__ = 'WeekDay_DateDay'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    date = sqlalchemy.Column(sqlalchemy.Date, nullable=False)
    weekday_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("BE_WeekDay.id"))
    is_holliday = sqlalchemy.Column(sqlalchemy.Boolean, default=False, nullable=False)


def WeekDay_DateDay_init():
    z = 1
    for i in range(0, 135):
        WeekDay_DateDay1 = WeekDay_DateDay()
        now = datetime.datetime(2021, 1, 11)
        d = now + timedelta(i)
        WeekDay_DateDay1.date = d
        WeekDay_DateDay1.weekday_id = z
        if z == 7:
            WeekDay_DateDay1.is_holliday = True
        if z != 7:
            z += 1
        else:
            z = 1
        db_sess = db_session.create_session()
        db_sess.add(WeekDay_DateDay1)
        db_sess.commit()
