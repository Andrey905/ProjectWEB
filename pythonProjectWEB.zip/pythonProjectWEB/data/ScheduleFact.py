import sqlalchemy
from flask import Flask
import sqlalchemy.ext.declarative as dec
from data import db_session
from .db_session import SqlAlchemyBase


class ScheduleFact(SqlAlchemyBase):
    __tablename__ = 'ScheduleFact'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    date_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("WeekDay_DateDay.id")) 
    schedule_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("D_Schedule.id"))
    is_change = sqlalchemy.Column(sqlalchemy.Boolean, default=False, nullable=False)


def ScheduleFact_init():
    db_session.global_init('D:/DB DZ/db/blogs.db')
    db_sess = db_session.create_session()
    from data.WeekDay_DateDay import WeekDay_DateDay
    from data.D_Schedule import D_Schedule
    query = db_sess.query(WeekDay_DateDay, D_Schedule)
    records = query.filter(D_Schedule.weekday_id == WeekDay_DateDay.weekday_id)
    for WeekDay_DateDay, D_Schedule in records:
        ScheduleFact1 = ScheduleFact()
        ScheduleFact1.date_id = WeekDay_DateDay.id
        ScheduleFact1.schedule_id = D_Schedule.id
        ScheduleFact1.is_change = False
        db_sess = db_session.create_session()
        db_sess.add(ScheduleFact1)
        db_sess.commit()
