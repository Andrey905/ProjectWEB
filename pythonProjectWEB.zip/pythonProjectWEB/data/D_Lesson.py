import sqlalchemy
from data import db_session
from .db_session import SqlAlchemyBase


class D_Lesson(SqlAlchemyBase):
    __tablename__ = 'D_Lesson'

    id = sqlalchemy.Column(sqlalchemy.Integer, 
                           primary_key=True, autoincrement=True, nullable=False)
    lesson_name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    lesson_name_eng = sqlalchemy.Column(sqlalchemy.String, nullable=False)


def D_Lesson_init():
    d = ['Физика', 'Алгебра', 'Геометрия', 'Русский', 'Английский', 'Физкультура', 'География', 'История', 'Биология', 'Химия', 'ОБЖ', 'Обществознание', 'Информатика', 'Литература']
    e = ['Physics', 'Algebra', 'Geometry', 'Russian', 'English', 'Sport', 'Geography', 'History', 'Biology', 'Chemistry', 'OBZH', 'Social', 'Computer', 'Literature']
    for i in range(len(d)):
        D_Lesson1 = D_Lesson()
        D_Lesson1.lesson_name = d[i]
        D_Lesson1.lesson_name_eng = e[i]
        db_sess = db_session.create_session()
        db_sess.add(D_Lesson1)
        db_sess.commit()
