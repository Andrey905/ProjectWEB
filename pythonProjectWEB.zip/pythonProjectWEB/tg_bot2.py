# Импортируем все файлы, функции, библиотеки, которые нам пригодятся
from telegram.ext import Updater, MessageHandler, Filters
from telegram.ext import CallbackContext, CommandHandler
from telegram.ext import CommandHandler
from telegram import ReplyKeyboardMarkup, ReplyKeyboardRemove
import time
import datetime
import sqlite3
from tomorrow import tomorrow
from home_work_write import hw1
from home_work_read import hw2
from home_work_read_all import hw4
from data.D_Lesson import D_Lesson
from data.BE_Lesson_Time import BE_Lesson_Time
from data.WeekDay_DateDay import WeekDay_DateDay
from data.HomeWork import HomeWork
from data.D_Schedule import D_Schedule
from data.ScheduleFact import ScheduleFact


# Функция для принятия текста
def echo(update, context):
    global text
    update.message.reply_text('Я запомнил ' + update.message.text)
    text = update.message.text


def main():
    global dp
    updater = Updater("1709022011:AAH-hXlv7LY8H0EtZD0wT9ciP93pq0zX5lA", use_context=True)
    # Все команды привязанные к функциям
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("sc", tomorrow))
    dp.add_handler(CommandHandler("hww", hw1))
    dp.add_handler(CommandHandler("hw", hw3))
    dp.add_handler(CommandHandler("hwr", hw2))
    dp.add_handler(CommandHandler("hwall", hw4))
    dp.add_handler(CommandHandler("hwrr", hr))
    dp.add_handler(CommandHandler("date", date1))
    dp.add_handler(CommandHandler("opb", open_keyboard))
    dp.add_handler(CommandHandler("clb", close_keyboard))
    dp.add_handler(CommandHandler("ol", open_keyboard_lesson))
    dp.add_handler(CommandHandler("cl", close_keyboard_lesson))
    dp.add_handler(CommandHandler("od", open_keyboard_date))
    dp.add_handler(CommandHandler("cd", close_keyboard_date))
    dp.add_handler(CommandHandler("Physics", ph))
    dp.add_handler(CommandHandler("Algebra", alg))
    dp.add_handler(CommandHandler("Geometry", gm))
    dp.add_handler(CommandHandler("Russian", rus))
    dp.add_handler(CommandHandler("English", en))
    dp.add_handler(CommandHandler("Sport", sp))
    dp.add_handler(CommandHandler("Geography", gg))
    dp.add_handler(CommandHandler("History", his))
    dp.add_handler(CommandHandler("Biology", bio))
    dp.add_handler(CommandHandler("Chemistry", ch))
    dp.add_handler(CommandHandler("OBZH", obg))
    dp.add_handler(CommandHandler("Social", so))
    dp.add_handler(CommandHandler("Computer", co))
    dp.add_handler(CommandHandler("Literature", lit))
    dp.add_handler(CommandHandler("help", helpp))
    text_handler = MessageHandler(Filters.text, echo)
    dp.add_handler(text_handler)
    updater.start_polling()
    updater.idle()


# Начальная клавиатура
reply_keyboard = [['/sc', '/date'],
                  ['/clb', '/help']]

li = list()
con = sqlite3.connect('db/blogs.db')
cur = con.cursor()
result = cur.execute("""SELECT D_Lesson.lesson_name_eng FROM D_Lesson""").fetchall()
for elem in result:
    b = elem[0]
    li.append('/' + str(b))
con.close()
reply_keyboard_lesson = [li]


def tm():
    return time.asctime()


# Функция вывода сегоднящний даты
def date1(update, context):
    a = time.asctime()
    a = a.split(' ')
    a1 = a[2] + ' ' + a[1] + ' ' + a[0]
    update.message.reply_text(a1)


markup = ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True)
markup1 = ReplyKeyboardMarkup(reply_keyboard_lesson, one_time_keyboard=True)


# Функция открывающая начальную клавиатуру
def open_keyboard(update, context):
    update.message.reply_text('Ок', reply_markup=markup)


# Функция закрывающая начальную клавиатуру
def close_keyboard(update, context):
    update.message.reply_text('Ок', reply_markup=ReplyKeyboardRemove())


# Функция открывающая клавиатуру с уроками
def open_keyboard_lesson(update, context):
    update.message.reply_text('Ок', reply_markup=markup1)


# Функция закрывающая клавиатуру с уроками
def close_keyboard_lesson(update, context):
    update.message.reply_text('Ок', reply_markup=ReplyKeyboardRemove())


# Функиция открывающая клавиатуру с датами
def open_keyboard_date(update, context):
    update.message.reply_text('Ок', reply_markup=markup2)


# Функиция закрывающая клавиатуру с датами
def close_keyboard_date(update, context):
    update.message.reply_text('Ок', reply_markup=ReplyKeyboardRemove())


# Функция кнопки предмета в клавиатуре с предметами
def ph(update, context):
    global predmet
    predmet = 'Физика'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def alg(update, context):
    global predmet
    predmet = 'Алгебра'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def gm(update, context):
    global predmet
    predmet = 'Геометрия'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def rus(update, context):
    global predmet
    predmet = 'Русский'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def en(update, context):
    global predmet
    predmet = 'Английский'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def sp(update, context):
    global predmet
    predmet = 'Физкультура'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def gg(update, context):
    global predmet
    predmet = 'География'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def his(update, context):
    global predmet
    predmet = 'История'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def bio(update, context):
    global predmet
    predmet = 'Биология'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def ch(update, context):
    global predmet
    predmet = 'Химия'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def obg(update, context):
    global predmet
    predmet = 'ОБЖ'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def so(update, context):
    global predmet
    predmet = 'Обществознание'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def co(update, context):
    global predmet
    predmet = 'Информатика'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция кнопки предмета в клавиатуре с предметами
def lit(update, context):
    global predmet
    predmet = 'Литература'
    reply_keyboard_date = date_lesson(predmet)
    markup2 = ReplyKeyboardMarkup(reply_keyboard_date, one_time_keyboard=True)
    update.message.reply_text('Ок', reply_markup=markup2)


# Функция определения ближайщих дат в расписании по предмету, введённому с клавиатуры
def date_lesson(predmet):
    dt = list()
    d = datetime.datetime.today().date()
    con = sqlite3.connect('D:/DB DZ/db/blogs.db')
    cur = con.cursor()
    result = cur.execute("""SELECT distinct WeekDay_DateDay.date FROM WeekDay_DateDay
        JOIN ScheduleFact on WeekDay_DateDay.id = ScheduleFact.date_id
        JOIN D_Schedule on ScheduleFact.schedule_id = D_Schedule.id
        JOIN D_Lesson on D_Schedule.lesson_id = D_Lesson.id
        where WeekDay_DateDay.date > '%s'
        and D_Lesson.lesson_name = '%s'""" % (d, predmet)).fetchall()
    for elem in result:
        b = elem[0]
        dt.append(b)
    con.close()
    if len(dt) > 6:
        dt = dt[:6]
    return [dt]


# Функция записи дз по данным с клавиатур
def hw3(update, context):
    global text, predmet
    a = context.args
    dt = text
    les = predmet
    dz = (' ').join(a)
    import sqlalchemy
    from flask import Flask
    import sqlalchemy.ext.declarative as dec
    from data import db_session
    from data.db_session import SqlAlchemyBase
    db_session.global_init('db/blogs.db')
    db_sess = db_session.create_session()
    from data.WeekDay_DateDay import WeekDay_DateDay
    for WeekDay_DateDay in db_sess.query(WeekDay_DateDay).filter(WeekDay_DateDay.date == dt):
        id_day = WeekDay_DateDay.id
    HomeWork1 = HomeWork()
    HomeWork1.date_id = id_day
    HomeWork1.text_homework = dz

    con = sqlite3.connect('D:/DB DZ/db/blogs.db')
    cur = con.cursor()
    result = cur.execute("""SELECT ScheduleFact.id FROM ScheduleFact
        JOIN D_Schedule on ScheduleFact.schedule_id = D_Schedule.id
        JOIN WeekDay_DateDay on ScheduleFact.date_id = WeekDay_DateDay.id
        JOIN D_Lesson on D_Schedule.lesson_id = D_Lesson.id
        where WeekDay_DateDay.date = '%s'
        and D_Lesson.lesson_name = '%s'""" % (dt, les)).fetchall()
    for elem in result:
        b = elem[0]
    con.close()

    HomeWork1.schedulefact_id = b
    db_sess = db_session.create_session()
    db_sess.add(HomeWork1)
    db_sess.commit()
    update.message.reply_text("записано")


# Функция отметки о выполнении дз
def hr(update, context):
    import sqlite3
    con = sqlite3.connect('D:/DB DZ/db/blogs.db')
    cur = con.cursor()
    a = context.args
    result = """Update HomeWork set result_type = 1 where id = '%s'""" % (str(a[0]))
    cur.execute(result)
    con.commit()
    con.close()


# Функция возвращающая описание команд бота
def helpp(update, context):
    update.message.reply_text("""описание
/sc - [/sc] [число] расписание уроков через [число] дней, без параметра на завтра
/hww - [/hww] [дата] [предмет] [текст дз] запись дз на [дата] по [предмет] 
/hw - [/hw] [текст дз] запись дз после предварительного введения параметров с клавиатур
/hwr - [/hwr] [число] всего списка дз через [число] дней, без параметра на завтра
/hwall - [/hwall] вывод всего списка дз с завтрашнего дня
/hwrr - [/hwrr] [число] отметка о выполнении дз с [число] = id записи дз
/date - [/date] вывод текущей даты
/opb - [/opb] открытие основной клавиатуры
/clb - [/clb] закрытие основной клавиатуры 
/ol - [/ol] открытие клавиатуры с предметами для записи дз
/cl - [/ol] закрытие клавиатуры с предметами для записи дз 
/cd - [/cd] закрытие клавиатуры с датами для записи дз""")


# Функция при первом запуске бота
def start(update, context):
    update.message.reply_text("""Добро пожаловать, я бот для записи твоего домашнего задания.
команда - /help покажет, что я умею.""")


if __name__ == '__main__':
    main()
