# Функция для вывода дз через заданное число дней
def hw2(update, context):
    if len(context.args) >= 1:
        d = int(context.args[0])
    else:
        d = 1
    from datetime import timedelta
    import datetime
    import time
    seconds = time.time() + d * 24 * 60 * 60
    a = time.ctime(seconds)
    a = a.split(' ')
    a1 = a[2] + ' ' + a[1] + ' ' + a[0]
    update.message.reply_text(a1)
    from data.WeekDay_DateDay import WeekDay_DateDay
    from data.D_Schedule import D_Schedule
    from data.BE_Lesson_Time import BE_Lesson_Time
    from data.BE_WeekDay import BE_WeekDay
    from data.D_Lesson import D_Lesson
    from data.ScheduleFact import ScheduleFact
    from data.HomeWork import HomeWork
    now = datetime.datetime.today()
    tomorrow = now + timedelta(d)
    tomorrow = tomorrow.date()
    import sqlite3
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    result = cur.execute("""SELECT HomeWork.id, D_Lesson.lesson_name, HomeWork.text_homework, HomeWork.result_type FROM HomeWork
        JOIN ScheduleFact on HomeWork.schedulefact_id = ScheduleFact.id
        JOIN D_Schedule on ScheduleFact.schedule_id = D_Schedule.id
        JOIN WeekDay_DateDay on ScheduleFact.date_id = WeekDay_DateDay.id
        JOIN D_Lesson on D_Schedule.lesson_id = D_Lesson.id
        where WeekDay_DateDay.date = '%s'""" % (tomorrow)).fetchall()
    for elem in result:
        b = elem
        if b[3] == 0:
            res = 'Не выполнено'
        else:
            res = 'Выполнено'
        update.message.reply_text(str(b[0]) + ': ' + b[1] + ' - ' + b[2] + ', ' + res)
    con.close()
    update.message.reply_text("Желаю удачи!:)")
