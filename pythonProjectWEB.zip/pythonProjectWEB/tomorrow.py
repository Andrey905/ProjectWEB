# Функция
def tomorrow(update, context):
    if len(context.args) >= 1:
        d = int(context.args[0])
    else:
        d = 1
    from datetime import timedelta
    import datetime
    import time
    seconds = time.time() + d * 24 * 60 * 60
    a = time.ctime(seconds)
    a = a.split(' ')
    a1 = a[2] + ' ' + a[1] + ' ' + a[0]
    update.message.reply_text(a1)
    import sqlalchemy
    from flask import Flask
    import sqlalchemy.ext.declarative as dec
    from data import db_session
    from data.WeekDay_DateDay import WeekDay_DateDay
    from data.D_Schedule import D_Schedule
    from data.BE_Lesson_Time import BE_Lesson_Time
    from data.BE_WeekDay import BE_WeekDay
    from data.D_Lesson import D_Lesson
    from data.ScheduleFact import ScheduleFact
    import datetime
    from datetime import timedelta
    db_session.global_init('db/blogs.db')
    db_sess = db_session.create_session()
    now = datetime.datetime.today()
    tomorrow = now + timedelta(d)

    query = db_sess.query(ScheduleFact, WeekDay_DateDay, D_Schedule, D_Lesson, BE_Lesson_Time)
    query = query.join(WeekDay_DateDay, WeekDay_DateDay.id == ScheduleFact.date_id)
    query = query.join(D_Schedule, D_Schedule.id == ScheduleFact.schedule_id)
    query = query.join(D_Lesson, D_Lesson.id == D_Schedule.lesson_id)
    query = query.join(BE_Lesson_Time, BE_Lesson_Time.lesson_num == D_Schedule.lesson_num)

    records = query.order_by(WeekDay_DateDay.date, D_Schedule.lesson_num).filter(WeekDay_DateDay.date == tomorrow.date())
    for ScheduleFact, WeekDay_DateDay, D_Schedule, D_Lesson, BE_Lesson_Time in records:
        answer = str(D_Schedule.lesson_num) + '. ' + str(BE_Lesson_Time.lessontime) + ' ' + str(D_Lesson.lesson_name)
        update.message.reply_text(answer)
