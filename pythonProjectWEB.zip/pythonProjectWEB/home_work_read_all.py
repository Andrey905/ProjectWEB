def hw4(update, context):
    import datetime
    d = datetime.datetime.today().date()
    from data.WeekDay_DateDay import WeekDay_DateDay
    from data.D_Schedule import D_Schedule
    from data.BE_Lesson_Time import BE_Lesson_Time
    from data.BE_WeekDay import BE_WeekDay
    from data.D_Lesson import D_Lesson
    from data.ScheduleFact import ScheduleFact
    from data.HomeWork import HomeWork
    import sqlite3
    con = sqlite3.connect('db/blogs.db')
    cur = con.cursor()
    result = cur.execute("""SELECT WeekDay_DateDay.date, HomeWork.id, D_Lesson.lesson_name, HomeWork.text_homework, HomeWork.result_type FROM HomeWork
        JOIN ScheduleFact on HomeWork.schedulefact_id = ScheduleFact.id
        JOIN D_Schedule on ScheduleFact.schedule_id = D_Schedule.id
        JOIN WeekDay_DateDay on ScheduleFact.date_id = WeekDay_DateDay.id
        JOIN D_Lesson on D_Schedule.lesson_id = D_Lesson.id
        where WeekDay_DateDay.date > '%s'""" % (d)).fetchall()
    for elem in result:
        b = elem
        if b[4] == 0:
            res = 'Не выполнено'
        else:
            res = 'Выполнено'
        update.message.reply_text(b[0] + ' ' + str(b[1]) + ': ' + b[2] + ' - ' + b[3] + ', ' + res)
    con.close()
    update.message.reply_text("Желаю удачи!:)")

